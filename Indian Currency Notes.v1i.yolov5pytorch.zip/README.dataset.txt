# Indian Currency Notes > 2023-10-05 4:09pm
https://universe.roboflow.com/pesuio/indian-currency-notes-uezrx

Provided by a Roboflow user
License: CC BY 4.0

